class ListSelection {
  String id; // Add this line
  String name;
  bool isSelected;
  String level;
  String? question; // Additional property for description

  ListSelection({
    required this.id, // Add this line
    required this.name,
    required this.level,
    this.isSelected = false,
    this.question,
  });

  ListSelection.fromMap(Map<String, dynamic> map, String id)
      : id = map['id'] ?? '', // Add this line
        name = map['name'] ?? '',
        level = map['level'] ?? '',
        isSelected = map['isSelected'] ?? false,
        question = map['question'] ?? ''.toString();

  Map<String, dynamic> toMap() {
    return {
      'id': id, // Add this line
      'name': name,
      'isSelected': isSelected,
      'level': level,
      'question': question,
    };
  }
}
