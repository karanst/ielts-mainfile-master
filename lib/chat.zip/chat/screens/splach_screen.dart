import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';
import 'package:ielts/chat/api/apis.dart';
import 'package:ielts/chat/screens/auth/login_screen.dart';
import 'package:ielts/main.dart';

import '../main.dart';
import 'home_screen.dart';

class SplashScreens extends StatefulWidget {
  const SplashScreens({super.key});

  @override
  State<SplashScreens> createState() => _SplashScreensState();
}

class _SplashScreensState extends State<SplashScreens> {
  @override
  void initState() {
    super.initState();
    Future.delayed(Duration(milliseconds: 1500), () {
      SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
      SystemChrome.setSystemUIOverlayStyle(
          SystemUiOverlayStyle(statusBarColor: Colors.transparent));
      SystemUiOverlayStyle(
          systemNavigationBarColor: Colors.white, statusBarColor: Colors.white);
      if (APIs.auth.currentUser != null) {
        Navigator.pushReplacement(
            context, MaterialPageRoute(builder: (_) => HomeScreens()));
      } else {
        Navigator.pushReplacement(
            context, MaterialPageRoute(builder: (_) => LoginScreen()));
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    mq = MediaQuery.of(context).size;
    return Scaffold(
      //appbar

      //appbar
      body: Stack(
        children: [
          Positioned(
            top: mq.height * .10,
            right: mq.width * .25,
            width: mq.width * .5,
            child: Image.asset('assets/icon.png'),
          ),
          Positioned(
              bottom: mq.height * .15,
              width: mq.width,
              child: Center(
                  child: Text(
                'Make it with love for you',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                ),
              )))
        ],
      ),
    );
  }
}
