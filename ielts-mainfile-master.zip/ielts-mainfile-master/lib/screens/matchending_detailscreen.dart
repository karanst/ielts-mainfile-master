import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../models/matchendings.dart';

class MatchEndingsDetailScreen extends StatefulWidget {
  final MatchEndings reading;

  MatchEndingsDetailScreen({ required this.reading});

  @override
  _MatchEndingsDetailScreenState createState() =>
      _MatchEndingsDetailScreenState();
}

class _MatchEndingsDetailScreenState extends State<MatchEndingsDetailScreen> {
  @override
  Widget build(BuildContext context) {
    ScreenUtil.init(context);

    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Match Endings Detail',
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(
            fontFamily: 'Montserrat',
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: ScreenUtil().setSp(18),
          ),
        ),
        elevation: 0.0,
        backgroundColor: Theme.of(context).primaryColor,
        bottomOpacity: 0.0,
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            SizedBox(height: ScreenUtil().setHeight(20)),
            Container(
              height: MediaQuery.of(context).size.height,
              decoration: BoxDecoration(
                boxShadow: [
                  BoxShadow(
                    color: Theme.of(context).secondaryHeaderColor,
                    blurRadius: 10,
                  )
                ],
                color: Theme.of(context).canvasColor,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(ScreenUtil().setWidth(75)),
                ),
              ),
              child: Padding(
                padding: EdgeInsets.all(ScreenUtil().setWidth(10)),
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: EdgeInsets.all(ScreenUtil().setHeight(14)),
                        child: Text(
                          'Match Endings Detail                 ',
                          style: TextStyle(
                            fontFamily: 'Montserrat',
                            fontWeight: FontWeight.bold,
                            fontSize: ScreenUtil().setSp(20),
                            color: Color(0xFF21BFBD),
                          ),
                        ),
                      ),

                      Text(
                        'Text: ${widget.reading.text}',
                        style: TextStyle(
                          fontFamily: 'Montserrat',
                          fontSize: ScreenUtil().setSp(16),
                        ),
                      ),
                      SizedBox(height: ScreenUtil().setHeight(20)),
                      Text(
                        'Main Text: ${widget.reading.mainText}',
                        style: TextStyle(
                          fontFamily: 'Montserrat',
                          fontSize: ScreenUtil().setSp(16),
                        ),
                      ),
                      Text(
                        'Ending Text: ${widget.reading.endingText}',
                        style: TextStyle(
                          fontFamily: 'Montserrat',
                          fontSize: ScreenUtil().setSp(16),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
