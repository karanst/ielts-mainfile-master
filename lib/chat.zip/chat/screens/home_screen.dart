import 'dart:convert';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';
import 'package:flutter_launcher_icons/web/web_icon_generator.dart';
import 'package:get/get.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:ielts/chat/models/chat_user.dart';
import 'package:ielts/chat/screens/profile_screen.dart';
import 'package:ielts/chat/widgets/chat_user_card.dart';
import 'package:ielts/main.dart';
import 'package:ielts/screens/headingcompletiondetails.dart';
import 'package:ielts/screens/home_screen.dart';
import 'package:ielts/widgets/adsHelper.dart';

import '../api/apis.dart';
import '../main.dart';

class HomeScreens extends StatefulWidget {
  const HomeScreens({super.key});

  @override
  State<HomeScreens> createState() => _HomeScreensState();
}

class _HomeScreensState extends State<HomeScreens> {
  //for storing all user
  List<ChatUser> _list = [];
  //for searing user

  final List<ChatUser> _searchList = [];
  // for storing search status
  bool _isSearching = false;
  final _adController = NativeAdController();

  void initState() {
    super.initState();
    APIs.getSelfInfo();

    SystemChannels.lifecycle.setMessageHandler((message) {
      if (APIs.auth.currentUser != null) {
        if (message.toString().contains('resume'))
          APIs.updateActiveStatus(false);
        if (message.toString().contains('pause'))
          APIs.updateActiveStatus(false);
      }

      return Future.value(message);
    });
  }

  @override
  Widget build(BuildContext context) {
    _adController.ad = AdHelper.loadNativeAd(adController: _adController);

    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: WillPopScope(
        onWillPop: () {
          if (_isSearching) {
            setState(() {
              _isSearching = !_isSearching;
            });
            return Future.value(false);
          } else {
            return Future.value(true);
          }
        },
        child: Scaffold(
          // bottomNavigationBar: _adController.ad != null &&
          //         _adController.adLoaded.isTrue
          //     ? SizedBox(
          //         height: 120,
          //         child: AdWidget(
          //             ad: _adController.ad!), // Create and load a new ad object
          //       )
          //     : null,

          //appbar
          backgroundColor: Colors.white,
          appBar: AppBar(
            backgroundColor: Colors.teal,
            elevation: 0, // Removes shadow
            leading: IconButton(
              onPressed: () {},
              icon: Icon(
                CupertinoIcons.home,
                color: Colors.black,
              ),
            ),
            centerTitle: true,
            title: _isSearching
                ? TextField(
                    autofocus: true,
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 18,
                    ),
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      hintText: 'Search name or email...',
                      hintStyle: TextStyle(
                        color: Colors.grey,
                        fontSize: 16,
                      ),
                    ),
                    onChanged: (val) {
                      // Search logic
                      _searchList.clear();
                      for (var i in _list) {
                        if (i.name.toLowerCase().contains(val.toLowerCase()) ||
                            i.email.toLowerCase().contains(val.toLowerCase())) {
                          _searchList.add(i);
                        }
                      }
                      setState(() {
                        _searchList;
                      });
                    },
                  )
                : Text(
                    'IELTS- YAN',
                    style: TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                      fontSize: 22,
                    ),
                  ),
            actions: [
              IconButton(
                onPressed: () {
                  if (!premium_user_google_play) {
                    ads.showInterstitialAd();
                    // AdHelper.initAds();
                    // AdHelper.showInterstitialAd();
                  }
                  setState(() {
                    _isSearching = !_isSearching;
                  });
                },
                icon: Icon(
                  _isSearching
                      ? CupertinoIcons.clear_circled_solid
                      : Icons.search,
                  color: Colors.black,
                ),
              ),
              IconButton(
                onPressed: () {
                  if (!premium_user_google_play) {
                    ads.showInterstitialAd();

                    AdHelper.showInterstitialAd(onComplete: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => ProfileScreen(
                            user: APIs.me,
                          ),
                        ),
                      );
                    });
                  }
                },
                icon: Icon(
                  Icons.person,
                  color: Colors.black,
                ),
              ),
            ],
          ),

          //appbar

          //floatingActionButton:
          // floatingActionButton: Padding(
          //   padding: const EdgeInsets.only(
          //     bottom: 10,
          //   ),
          //   child: FloatingActionButton(
          //     onPressed: () async {
          //       await APIs.auth.signOut();
          //       await GoogleSignIn().signOut();
          //     },
          //     child: Icon(
          //       Icons.add_comment_outlined,
          //     ),
          //   ),
          // ),

          //floatingActionButton:

          body: StreamBuilder(
            stream: APIs.getAllUsers(),
            builder: (BuildContext context, snapshot) {
              switch (snapshot.connectionState) {
                //if data is loding
                case ConnectionState.waiting:
                case ConnectionState.none:
                  return const Center(child: CircularProgressIndicator());
                //if data is loded
                case ConnectionState.active:
                case ConnectionState.done:
                  final data = snapshot.data?.docs;
                  _list =
                      data?.map((e) => ChatUser.fromJson(e.data())).toList() ??
                          [];
                  if (_list.isNotEmpty) {
                    return ListView.builder(
                      itemCount:
                          _isSearching ? _searchList.length : _list.length,
                      physics: BouncingScrollPhysics(),
                      padding: EdgeInsets.only(top: mq.height * .01),
                      itemBuilder: (context, index) {
                        return ChatUserCard(
                          user:
                              _isSearching ? _searchList[index] : _list[index],
                        );
                      },
                    );
                  } else {
                    return Center(child: Text('No connection found'));
                  }
              }
            },
          ),
        ),
      ),
    );
  }
}
