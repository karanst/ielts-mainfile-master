class MCQs {
  final String id;
  final String question;
  String level;
  final List<String> options;
  final int correctAnswerIndex;

  MCQs({
    required this.id,
    required this.question,
    required this.level,
    required this.options,
    required this.correctAnswerIndex,
  });

  factory MCQs.fromMap(Map<String, dynamic> map, String id) {
    return MCQs(
      id: id,
      question: map['question'] ?? '',
      level: map['level'] ?? '',
      options: List<String>.from(map['options'] ?? []),
      correctAnswerIndex: map['correctAnswerIndex'] ?? 0,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'question': question,
      'options': options,
      'level': level,
      'correctAnswerIndex': correctAnswerIndex,
    };
  }
}
