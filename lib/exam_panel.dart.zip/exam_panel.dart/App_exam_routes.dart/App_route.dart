// import 'package:get/get.dart';
// import 'package:ielts/exam_panel.dart/controllers/question_page/question_paper_controller.dart';
// import 'package:ielts/exam_panel.dart/screens/home/home_screen.dart';
// import 'package:ielts/utils/app_constants.dart';

// class AppRoutes {
//   static List<GetPage> route() => [
//         GetPage(
//           name: RoutePaths
//               .examHome, // Use the constant from your RoutePaths class
//           page: () => ExamHomeScreen(),
//           binding: BindingsBuilder(
//             () {
//               Get.put(QuestionPaperController());
//             },
//           ),
//         ),
//       ];
// }
