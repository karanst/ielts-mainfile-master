class SummaryCompletion {
  final String passage;
  final String id;
  String level;
  final List<String> options;
  final String correctOption;

  SummaryCompletion( {
    required this.passage,
    required this.id,
    required this.level,
    required this.options,
    required this.correctOption,
  });

  // Factory method to create a SummaryCompletion instance from a map
  factory SummaryCompletion.fromMap(Map<String, dynamic> map, String id) {
    return SummaryCompletion(
      id: id,
      passage: map['passage'] ?? "" ,
      // options: (map['options'] as List<dynamic>?)
      //     ?.map((dynamic item) => item.toString())
      //     .toList() ?? [''],
      correctOption: map['correctOption'] ?? '',
      level: map['level'] ?? '',
      options: List<String>.from(map['options']),

    );
  }

}