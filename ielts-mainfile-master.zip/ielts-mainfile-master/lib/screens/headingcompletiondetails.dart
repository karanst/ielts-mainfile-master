import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:ielts/models/headingcompletion.dart';

class HeadingCompletionDetailScreen extends StatefulWidget {
  final HeadingCompletion reading;

  HeadingCompletionDetailScreen({required this.reading});

  @override
  _HeadingCompletionDetailScreenState createState() =>
      _HeadingCompletionDetailScreenState();
}

class _HeadingCompletionDetailScreenState
    extends State<HeadingCompletionDetailScreen> {
  late List<bool> selectedHeadings;
  bool showColoredBox = false;

  @override
  void initState() {
    super.initState();
    selectedHeadings =
        List.generate(widget.reading.headings.length, (index) => false);
  }

  @override
  Widget build(BuildContext context) {
    ScreenUtil.init(context);

    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Heading Completion Detail',
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(
            fontFamily: 'Montserrat',
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: ScreenUtil().setSp(18),
          ),
        ),
        elevation: 0.0,
        backgroundColor: Theme.of(context).primaryColor,
        bottomOpacity: 0.0,
      ),
      body: Padding(
        padding: EdgeInsets.all(ScreenUtil().setWidth(0)),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: ScreenUtil().setHeight(20)),
              Container(
                height: MediaQuery.of(context).size.height,
                decoration: BoxDecoration(
                  boxShadow: [
                    BoxShadow(
                      color: Theme.of(context).secondaryHeaderColor,
                      blurRadius: 10,
                    )
                  ],
                  color: Theme.of(context).canvasColor,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(ScreenUtil().setWidth(75)),
                  ),
                ),
                child: Padding(
                  padding: EdgeInsets.all(ScreenUtil().setWidth(10)),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: EdgeInsets.all(ScreenUtil().setHeight(14)),
                        child: Text(
                          'Passage',
                          style: TextStyle(
                            fontFamily: 'Montserrat',
                            fontWeight: FontWeight.bold,
                            fontSize: ScreenUtil().setSp(20),
                            color: Color(0xFF21BFBD),
                          ),
                        ),
                      ),
                      ColoredBox(
                        color: Colors.blue.shade300,
                        child: Padding(
                          padding: EdgeInsets.all(ScreenUtil().setHeight(16)),
                          child: Text(
                            widget.reading.passage,
                            style: TextStyle(
                              fontSize: ScreenUtil().setSp(16),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(height: ScreenUtil().setHeight(20)),
                      Padding(
                        padding: EdgeInsets.all(ScreenUtil().setHeight(8)),
                        child: Text(
                          'Headings',
                          style: TextStyle(
                            fontFamily: 'Montserrat',
                            fontWeight: FontWeight.bold,
                            fontSize: ScreenUtil().setSp(20),
                            color: Color(0xFF21BFBD),
                          ),
                        ),
                      ),
                      ColoredBox(
                        color: Colors.blue.shade300,
                        child: Padding(
                          padding: EdgeInsets.all(ScreenUtil().setHeight(16)),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: List.generate(
                              widget.reading.headings.length,
                                  (index) => CheckboxListTile(
                                title: Text(widget.reading.headings[index]),
                                value: selectedHeadings[index],
                                onChanged: (value) {
                                  setState(() {
                                    selectedHeadings[index] = value ?? false;
                                  });
                                },
                                controlAffinity:
                                ListTileControlAffinity.leading,
                              ),
                            ),
                          ),
                        ),

                      ),
                      SizedBox(height: ScreenUtil().setHeight(20)),
                      Padding(
                        padding: EdgeInsets.all(ScreenUtil().setHeight(8)),
                        child: Text(
                          'Correct Option',
                          style: TextStyle(
                            fontFamily: 'Montserrat',
                            fontWeight: FontWeight.bold,
                            fontSize: ScreenUtil().setSp(20),
                            color: Color(0xFF21BFBD),
                          ),
                        ),
                      ),
                      Align(
                        alignment: Alignment.bottomCenter,
                        child: MaterialButton(
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10)),
                          onPressed: () {
                            setState(() {
                              showColoredBox = true;
                            });
                          },
                          child: Text('Answer',
                              style: TextStyle(
                                fontSize: ScreenUtil().setSp(20),
                                fontFamily: 'Montserrat',
                              )),
                          color: Colors.deepPurpleAccent,
                          textColor: Colors.white,
                          elevation: 5,
                        ),
                      ),
                      if (showColoredBox)
                        Center(
                          child: ColoredBox(
                            color: Colors.blue.shade300,
                            child: Padding(
                              padding: EdgeInsets.all(ScreenUtil().setHeight(16)),
                              child: Text(
                                widget.reading.correctoption.toString(),
                                style: TextStyle(
                                  fontSize: ScreenUtil().setSp(16),
                                ),
                              ),
                            ),
                          ),
                        ),


                    ],
                  ),



                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
