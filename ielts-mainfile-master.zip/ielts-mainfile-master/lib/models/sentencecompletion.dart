class SentenceCompletion {
  final String id;
  final String sentence;
  String level;
  final List<String> options;
  final String correctOption;

  SentenceCompletion({
    required this.id,
    required this.sentence,
    required this.level,
    required this.options,
    required this.correctOption,
  });

  factory SentenceCompletion.fromMap(Map<String, dynamic> map, String id) {
    return SentenceCompletion(
      id: id,
      sentence: map['sentence'] ?? '',
      level: map['level'] ?? '',
      options: List<String>.from(map['options'] ?? []),
      correctOption: map['correctOption'] ?? '',
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'sentence': sentence,
      'options': options,
      'correctOption': correctOption,
      'level': level,
    };
  }
}