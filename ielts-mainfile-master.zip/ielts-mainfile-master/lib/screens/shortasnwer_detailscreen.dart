import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../models/shortasnwers.dart';

class ShortAnswerDetailScreen extends StatefulWidget {
  final ShortAnswer reading;

  ShortAnswerDetailScreen({required this.reading});

  @override
  _ShortAnswerDetailScreenState createState() =>
      _ShortAnswerDetailScreenState();
}

class _ShortAnswerDetailScreenState extends State<ShortAnswerDetailScreen> {
  @override
  Widget build(BuildContext context) {
    ScreenUtil.init(context);

    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Short Answer Detail',
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(
            fontFamily: 'Montserrat',
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: ScreenUtil().setSp(18),
          ),
        ),
        elevation: 0.0,
        backgroundColor: Theme.of(context).primaryColor,
        bottomOpacity: 0.0,
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            SizedBox(height: ScreenUtil().setHeight(20)),
            Container(
              height: MediaQuery.of(context).size.height,
              decoration: BoxDecoration(
                boxShadow: [
                  BoxShadow(
                    color: Theme.of(context).secondaryHeaderColor,
                    blurRadius: 10,
                  )
                ],
                color: Theme.of(context).canvasColor,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(ScreenUtil().setWidth(75)),
                ),
              ),
              child: Padding(
                padding: EdgeInsets.all(ScreenUtil().setWidth(10)),
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: EdgeInsets.all(ScreenUtil().setWidth(14)),
                        child: Text(
                          'Short Answer Detail                   ',
                          style: TextStyle(
                            fontFamily: 'Montserrat',
                            fontWeight: FontWeight.bold,
                            fontSize: ScreenUtil().setSp(20),
                            color: Color(0xFF21BFBD),
                          ),
                        ),
                      ),
                      Text(
                        'Question: ${widget.reading.question}',
                        style: TextStyle(
                          fontFamily: 'Montserrat',
                          fontSize: ScreenUtil().setSp(16),
                        ),
                      ),
                      Text(
                        'User Answer: ${widget.reading.userAnswer}',
                        style: TextStyle(
                          fontFamily: 'Montserrat',
                          fontSize: ScreenUtil().setSp(16),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
