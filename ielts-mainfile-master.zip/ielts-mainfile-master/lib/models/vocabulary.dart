class Vocabulary {
  String word;
  String description;
  String sentence;

  Vocabulary({
    required this.word,
    required this.description,
    required this.sentence,
  });
}
