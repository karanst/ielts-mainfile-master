import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:ielts/models/trueorfalse.dart';
import 'package:ielts/screens/home_screen.dart';
import 'package:ielts/services/admob_service.dart';

import '../models/reading.dart';

final Color backgroundColor = Color(0xFF21BFBD);

class ReadingDetailScreen extends StatefulWidget {
  late final TrueOrFalse reading;


  ReadingDetailScreen({
    required this.reading,
  });

  @override
  _ReadingDetailScreenState createState() => _ReadingDetailScreenState(reading);
}
final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
class _ReadingDetailScreenState extends State<ReadingDetailScreen>
    with SingleTickerProviderStateMixin {
  late final TrueOrFalse reading;

  _ReadingDetailScreenState(this.reading);

  var initialQuestionResult;
  var endingQuestionResult;
  var answersResult;
  final ams = AdMobService();
  bool isCollapsed = true;
  late double screenWidth, screenHeight;
  final Duration duration = const Duration(milliseconds: 300);

  @override
  void initState() {
    super.initState();
    ams.getAdMobAppId();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    ScreenUtil.init(context);
    Size size = MediaQuery.of(context).size;
    screenHeight = size.height;
    screenWidth = size.width;

    return Scaffold(
      key: _scaffoldKey,
      appBar: AppBar(
        title: Text(
          "True False",
          maxLines: 3,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(
            fontFamily: 'Montserrat',
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: ScreenUtil().setSp(16),
          ),
        ),
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios),
          color: Colors.white,
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
        elevation: 0.0,
        backgroundColor: Theme.of(context).primaryColor,
        bottomOpacity: 0.0,
      ),
      body: Material(
        animationDuration: duration,
        elevation: 8,
        color: Theme.of(context).primaryColor,
        child: SingleChildScrollView(
          scrollDirection: Axis.vertical,
          physics: ClampingScrollPhysics(),
          child: Container(
            padding: const EdgeInsets.only(top: 10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                // Container for the main content
                Container(
                  decoration: BoxDecoration(
                    boxShadow: [
                      BoxShadow(
                        color: Theme.of(context).secondaryHeaderColor,
                        blurRadius: 10,
                      ),
                    ],
                    color: Theme.of(context).canvasColor,
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(ScreenUtil().setWidth(75)),
                    ),
                  ),
                  child: Padding(
                    padding: EdgeInsets.all(10),
                    child: ListView(
                      scrollDirection: Axis.vertical,
                      padding: EdgeInsets.only(
                        top: ScreenUtil().setHeight(40),
                      ),
                      shrinkWrap: true,
                      physics: ScrollPhysics(),
                      children: <Widget>[
                        Padding(
                          padding: EdgeInsets.all(ScreenUtil().setHeight(8)),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('Level'),
                              Text(
                                reading.level,
                                style: TextStyle(
                                  fontFamily: 'Montserrat',
                                  fontWeight: FontWeight.bold,
                                  fontSize: ScreenUtil().setSp(16),
                                  color: Color(0xFF21BFBD),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.all(ScreenUtil().setHeight(8)),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('Question:'),
                              Text(
                                reading.question.toString(),
                                style: TextStyle(
                                  fontFamily: 'Montserrat',
                                  fontWeight: FontWeight.bold,
                                  fontSize: ScreenUtil().setSp(18),
                                  color: Color(0xFF21BFBD),
                                ),
                              ),
                            ],
                          ),
                        ),

                        SizedBox(height: 16),

                        // Radio buttons for True/False
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text('True'),
                            Radio(
                              value: true,
                              groupValue: reading.isTrue,
                              onChanged: (value) {
                                // Update the model when True is selected
                                setState(() {
                                  reading.isTrue = true;
                                });
                              },
                            ),
                            Text('False'),
                            Radio(
                              value: false,
                              groupValue: reading.isTrue,
                              onChanged: (value) {
                                // Update the model when False is selected
                                setState(() {
                                  reading.isTrue = false;
                                });
                              },
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),

                // Container for the Answers button
                Container(
                  color: Colors.deepPurpleAccent,
                  child: Align(
                    alignment: Alignment.bottomCenter,
                    child: MaterialButton(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                      onPressed: () {
                        if (reading.isTrue != null) {
                          openBookingDetailsSheet(context, reading as TrueOrFalse);
                        } else {
                          // Show an error message or handle the case where
                          // the user hasn't selected True or False
                          // For example, you can display a SnackBar:
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text('Please select True or False.'),
                            ));
                        }
                      },
                      child: Text(
                        'Answers',
                        style: TextStyle(
                          fontSize: ScreenUtil().setSp(20),
                          fontFamily: 'Montserrat',
                        ),
                      ),
                      color: Colors.deepPurpleAccent,
                      textColor: Colors.white,
                      elevation: 5,
                    ),
                  ),
                ),

                // Additional UI elements for true/false strategies
                // Container(
                //   decoration: BoxDecoration(
                //     color: Colors.blue, // Change color as needed
                //     borderRadius: BorderRadius.circular(10),
                //   ),
                //   margin: EdgeInsets.all(10),
                //   padding: EdgeInsets.all(10),
                //   child: Column(
                //     crossAxisAlignment: CrossAxisAlignment.start,
                //     children: [
                //       Text(
                //         'True/False Strategies',
                //         style: TextStyle(
                //           fontFamily: 'Montserrat',
                //           fontWeight: FontWeight.bold,
                //           fontSize: ScreenUtil().setSp(18),
                //           color: Colors.white, // Change color as needed
                //         ),
                //       ),
                //       SizedBox(height: 10),
                //       Text(
                //         '1. Read the statements carefully.',
                //         style: TextStyle(
                //           fontFamily: 'Montserrat',
                //           fontSize: ScreenUtil().setSp(16),
                //           color: Colors.white, // Change color as needed
                //         ),
                //       ),
                //       Text(
                //         '2. Identify keywords in each statement.',
                //         style: TextStyle(
                //           fontFamily: 'Montserrat',
                //           fontSize: ScreenUtil().setSp(16),
                //           color: Colors.white, // Change color as needed
                //         ),
                //       ),
                //       Text(
                //         '3. Pay attention to negations like "not" or "never".',
                //         style: TextStyle(
                //           fontFamily: 'Montserrat',
                //           fontSize: ScreenUtil().setSp(16),
                //           color: Colors.white, // Change color as needed
                //         ),
                //       ),
                //     ],
                //   ),
                // ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void openBookingDetailsSheet(BuildContext context, TrueOrFalse reading) {
    showModalBottomSheet<Widget>(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10.0),
      ),
      context: context,
      builder: (BuildContext context) => ListView(
        physics: ScrollPhysics(),
        shrinkWrap: true,
        children: <Widget>[
          Container(
            padding: EdgeInsets.all(ScreenUtil().setHeight(10)),
            child: ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: 1,
              itemBuilder: (BuildContext context, int index) {
                answersResult = reading.isTrue.toString();
                return ListTile(
                  title: Text(
                    answersResult,
                    style: TextStyle(
                      fontFamily: 'Montserrat',
                      fontSize: ScreenUtil().setSp(13),
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                );
              },
            ),
          ),
          // Additional validation based on isTrue property
          if (reading.isTrue)
            Container(
              padding: EdgeInsets.all(ScreenUtil().setHeight(10)),
              child: Text(
                'Congratulations! Your answer is correct.',
                style: TextStyle(
                  fontFamily: 'Montserrat',
                  fontSize: ScreenUtil().setSp(16),
                  fontWeight: FontWeight.bold,
                  color: Colors.green,
                ),
              ),
            ),
          if (!reading.isTrue)
            Container(
              padding: EdgeInsets.all(ScreenUtil().setHeight(10)),
              child: Text(
                'Oops! Your answer is incorrect.',
                style: TextStyle(
                  fontFamily: 'Montserrat',
                  fontSize: ScreenUtil().setSp(16),
                  fontWeight: FontWeight.bold,
                  color: Colors.red,
                ),
              ),
            ),
        ],
      ),
    );
  }

}
