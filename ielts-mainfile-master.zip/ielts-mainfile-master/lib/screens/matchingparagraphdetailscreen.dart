import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:ielts/models/matchparagraphs.dart';

class MatchingParagraphsDetailScreen extends StatefulWidget {
  final MatchingParagraphs reading;

  MatchingParagraphsDetailScreen({required this.reading});

  @override
  _MatchingParagraphsDetailScreenState createState() =>
      _MatchingParagraphsDetailScreenState();
}

class _MatchingParagraphsDetailScreenState
    extends State<MatchingParagraphsDetailScreen> {
  List<int?> selectedOptions = [];
  bool showColoredBox = false;


  @override
  void initState() {
    super.initState();

    selectedOptions = List<int?>.filled(widget.reading.options.length, null);
  }

  @override
  Widget build(BuildContext context) {
    ScreenUtil.init(context);

    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Matching Paragraphs Detail',
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(
            fontFamily: 'Montserrat',
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: ScreenUtil().setSp(18),
          ),
        ),
        elevation: 0.0,
        backgroundColor: Theme.of(context).primaryColor,
        bottomOpacity: 0.0,
      ),
      body: Padding(
        padding: EdgeInsets.all(ScreenUtil().setWidth(0)),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: ScreenUtil().setHeight(20)),
              Container(
                height: MediaQuery.of(context).size.height * 1.6,
                decoration: BoxDecoration(
                  boxShadow: [
                    BoxShadow(
                      color: Theme.of(context).secondaryHeaderColor,
                      blurRadius: 10,
                    )
                  ],
                  color: Theme.of(context).canvasColor,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(ScreenUtil().setWidth(75)),
                  ),
                ),
                child: Padding(
                  padding: EdgeInsets.all(ScreenUtil().setWidth(10)),
                  child: SingleChildScrollView(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding: EdgeInsets.all(ScreenUtil().setHeight(14)),
                          child: Text(
                            'Paragraphs                                  ',
                            style: TextStyle(
                              fontFamily: 'Montserrat',
                              fontWeight: FontWeight.bold,
                              fontSize: ScreenUtil().setSp(20),
                              color: Color(0xFF21BFBD),
                            ),
                          ),
                        ),
                        ColoredBox(
                          color: Colors.white,
                          child: Padding(
                            padding: EdgeInsets.all(ScreenUtil().setHeight(16)),
                            child: Column(
                              children: List.generate(
                                widget.reading.paragraphs.length,
                                (index) =>

                                    Container(
                                      color: Colors.blue.shade300,
                                      margin: EdgeInsets.fromLTRB(0, 10, 0, 10),
                                      child: Text(
                                      widget.reading.paragraphs[index].toString(),
                                      style: TextStyle(
                                        fontSize: ScreenUtil().setSp(16),
                                      ),
                                    ),)
                              ),
                            ),
                          ),
                        ),
                        SizedBox(height: ScreenUtil().setHeight(20)),
                        Padding(
                          padding: EdgeInsets.all(ScreenUtil().setHeight(8)),
                          child: Text(
                            'Options',
                            style: TextStyle(
                              fontFamily: 'Montserrat',
                              fontWeight: FontWeight.bold,
                              fontSize: ScreenUtil().setSp(20),
                              color: Color(0xFF21BFBD),
                            ),
                          ),
                        ),
                        ColoredBox(
                          color: Colors.blue.shade300,
                          child: Padding(
                            padding: EdgeInsets.all(ScreenUtil().setHeight(16)),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: List.generate(
                                widget.reading.options.length,
                                    (paragraphIndex) => Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      widget.reading.options[paragraphIndex]["sentence"].toString(),
                                      style: TextStyle(
                                        fontSize: ScreenUtil().setSp(16),
                                      ),
                                    ),
                                    Column(
                                      children: List.generate(
                                        widget.reading.options[paragraphIndex]["matchingParagraphOptions"].length,
                                            (optionIndex) => CheckboxListTile(
                                          title: Text(
                                            widget.reading.options[paragraphIndex]["matchingParagraphOptions"][optionIndex].toString(),
                                          ),
                                          value: selectedOptions.length > paragraphIndex &&
                                              selectedOptions[paragraphIndex] == optionIndex,
                                          onChanged: (value) {
                                            setState(() {
                                              // Ensure selectedOptions is a growable list
                                              selectedOptions = List.from(selectedOptions);
                                              while (selectedOptions.length <= paragraphIndex) {
                                                selectedOptions.add(null);
                                              }
                                              selectedOptions[paragraphIndex] =
                                              value! ? optionIndex : null;
                                            });
                                          },
                                          controlAffinity: ListTileControlAffinity.leading,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                        SizedBox(height: ScreenUtil().setHeight(20)),
                        Padding(
                          padding: EdgeInsets.all(ScreenUtil().setHeight(8)),
                          child: Text(
                            'Correct Option',
                            style: TextStyle(
                              fontFamily: 'Montserrat',
                              fontWeight: FontWeight.bold,
                              fontSize: ScreenUtil().setSp(20),
                              color: Color(0xFF21BFBD),
                            ),
                          ),
                        ),
                        Align(
                          alignment: Alignment.bottomCenter,
                          child: MaterialButton(
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10)),
                            onPressed: () {
                              setState(() {
                                showColoredBox = true;
                              });
                            },
                            child: Text('Answer',
                                style: TextStyle(
                                  fontSize: ScreenUtil().setSp(20),
                                  fontFamily: 'Montserrat',
                                )),
                            color: Colors.deepPurpleAccent,
                            textColor: Colors.white,
                            elevation: 5,
                          ),
                        ),
                        if (showColoredBox)
                          Center(
                            child: ColoredBox(
                              color: Colors.blue.shade300,
                              child: Padding(
                                padding: EdgeInsets.all(ScreenUtil().setHeight(16)),
                                child: Text(
                                  widget.reading.correctAnswers.join(", "),
                                  style: TextStyle(
                                    fontSize: ScreenUtil().setSp(16),
                                  ),
                                ),
                              ),
                            ),
                          ),

                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
