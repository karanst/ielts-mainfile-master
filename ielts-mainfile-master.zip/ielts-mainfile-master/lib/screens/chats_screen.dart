import 'package:flutter/material.dart';
import 'package:ielts/screens/home_screen.dart';
import 'package:ielts/utils/app_constants.dart'; // Import your home screen file

class ChatScreen extends StatefulWidget {
  const ChatScreen({Key? key}) : super(key: key);

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final TextEditingController _messageController = TextEditingController();

  List<String> messages = [
    "Hello!",
    "Hi there!",
    "How are you?",
    "I'm good, thanks!",
    "Flutter is amazing!",
  ];

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        // Navigate back to the home page when the back button is pressed
        Navigator.of(context).popUntil((route) => route.isFirst);
        return false; // Return false to prevent the default back button behavior
      },
      child: Scaffold(
        appBar: AppBar(
          title: Text('Chat Screen'),
          leading: IconButton(
            icon: Icon(Icons.arrow_back),
            onPressed: () {
              Navigator.pushNamed(context, RoutePaths.home);
            },
          ),
        ),
        body: Column(
          children: [
            Expanded(
              child: ListView.builder(
                itemCount: messages.length,
                itemBuilder: (context, index) {
                  return ListTile(
                    title: Text(messages[index]),
                    // You can customize the ListTile further, e.g., add sender's name, timestamp, etc.
                  );
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _messageController,
                      decoration: InputDecoration(
                        hintText: 'Type your message...',
                      ),
                    ),
                  ),
                  IconButton(
                    icon: Icon(Icons.send),
                    onPressed: () {
                      if (_messageController.text.isNotEmpty) {
                        setState(() {
                          messages.add(_messageController.text);
                          _messageController.clear();
                        });
                      }
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

void main() {
  runApp(MaterialApp(
    home: HomeScreen(), // Set your home screen as the initial route
  ));
}
