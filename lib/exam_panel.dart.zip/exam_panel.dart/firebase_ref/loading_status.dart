enum LoadingStatus {
  loading,
  completed,
  error,
}
