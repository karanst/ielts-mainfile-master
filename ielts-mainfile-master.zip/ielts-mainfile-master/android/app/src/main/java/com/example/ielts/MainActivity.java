package com.ieltsexam.ieltsyan;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
