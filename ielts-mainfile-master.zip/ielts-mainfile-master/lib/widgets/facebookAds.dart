import 'package:facebook_audience_network/facebook_audience_network.dart';
import 'package:get/get.dart';
import 'package:get/get_state_manager/src/simple/get_controllers.dart';
import 'dart:developer';
import 'package:ielts/widgets/remote-config.dart';

class AdManager {
  static bool _nativeAdLoaded = false;
  static FacebookNativeAd? _nativeAd;
  static bool _isInterstitialAdLoaded = false;
  static bool _isRewardedAdLoaded = false;

  static Future<void> fbinit() async {
   await FacebookAudienceNetwork.init(testingId: "1418545492107933");
    showInterstitialAd();

  }

  static void showInterstitialAd() {

  }

  static void showRewardedAd() {

  }

  static void showBannerAd() {

  }

  static FacebookNativeAd? loadNativeAd({required FbNativeAdController adController}) {
    log('Native Ad Id: ${FacebookConfig.nativeAd}');

    if (FacebookConfig.hideAds) return null;

    if (_nativeAdLoaded && _nativeAd != null) {
      adController.adLoaded.value = true;
      return _nativeAd;
    }

    _nativeAd = FacebookNativeAd(
      placementId: FacebookConfig.nativeAd,
      adType: NativeAdType.NATIVE_BANNER_AD,
      width: double.infinity,
      height: 100, // Adjust the height as needed
      listener: (result, value) {
        if (result == NativeAdResult.LOADED) {
          log('Native Ad loaded.');
          _nativeAdLoaded = true;
          adController.adLoaded.value = true;
        } else if (result == NativeAdResult.ERROR) {
          log('Native Ad failed to load: $value');
          _resetNativeAd();
        }
      },
    );

    // _nativeAd?.loadAd();
    return _nativeAd;
  }

  static void _resetNativeAd() {
    _nativeAdLoaded = false;
    _nativeAd = null;
  }
}
class FbNativeAdController extends GetxController {
  FacebookNativeAd? ad;
  final adLoaded = false.obs;
}

