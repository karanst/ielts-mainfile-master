
class HeadingCompletion {
  late final String id;
  late final String passage;
  String level;
  final String correctoption;
  late final List<String> headings;

  HeadingCompletion({
    required this.id,
    required this.passage,
    required this.level,
    required this.correctoption,
    required this.headings,
  });

  factory HeadingCompletion.fromMap(Map<String, dynamic> map, String documentId) {
    return HeadingCompletion(
      id: documentId,
      correctoption: map['correctoption'] ?? "",
      level: map['level'] ?? "",
      passage: map['passage'].toString(),
      headings: List<String>.from(map['headings']),
    );
  }
}