import 'package:flutter/material.dart';
// import 'package:ielts/widgets/zoom_scaffold.dart';

class MenuBloc extends ChangeNotifier {
  MenuController? menuController;
}
