class AdMobService {
  String getAdMobAppId() {
    return 'ca-app-pub-3133734302958653~2859571909';
  }

  String getBannerAdId() {
    return 'ca-app-pub-3133734302958653/4055241683';
  }
}
