class MatchingParagraphs {
  final String id;
  final List<String> paragraphs;
  // final List<List<String>> options;
  final List<Map> options;
  String level;
  final List<int> correctAnswers;

  MatchingParagraphs({
    required this.id,
    required this.paragraphs,
    required this.level,
    required this.options,
    required this.correctAnswers,
  });

  factory MatchingParagraphs.fromMap(Map<String, dynamic> map, String id) {
    return MatchingParagraphs(
      id: id,
      level: map['level'] ?? '',
      paragraphs: List<String>.from(map['paragraphs'] ?? []),
      // options: List<Map>.from(map['options']),
      options: List<Map>.from((map['options'] as List<dynamic>?) ?? {}),
      //?.map((opt) => List<String>.from(opt as List<dynamic>)) ?? []),

      // options: List<List<String>>.from((map['options'] as List<dynamic>?)?.map((opt) => List<String>.from(opt as List<dynamic>)) ?? []),
      correctAnswers: List<int>.from(map['correctAnswers'] ?? []),
    );
  }



  Map<String, dynamic> toMap() {
    return {
      'paragraphs': paragraphs,
      'options': options,
      'level': level,
      'correctAnswers': correctAnswers,
    };
  }
}