import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:ielts/models/sentencecompletion.dart';

class SentenceCompletionDetailScreen extends StatefulWidget {
  final SentenceCompletion reading;

  SentenceCompletionDetailScreen({required this.reading});

  @override
  _SentenceCompletionDetailScreenState createState() =>
      _SentenceCompletionDetailScreenState();
}

class _SentenceCompletionDetailScreenState
    extends State<SentenceCompletionDetailScreen> {
  late List<bool> selectedOptions;
  bool showColoredBox = false;

  @override
  void initState() {
    super.initState();
    selectedOptions =
        List.generate(widget.reading.options.length, (index) => false);
  }

  @override
  Widget build(BuildContext context) {
    ScreenUtil.init(context);

    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Sentence Completion Detail',
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(
            fontFamily: 'Montserrat',
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: ScreenUtil().setSp(18),
          ),
        ),
        elevation: 0.0,
        backgroundColor: Theme.of(context).primaryColor,
        bottomOpacity: 0.0,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.all(ScreenUtil().setWidth(0)),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: ScreenUtil().setHeight(20)),
              Container(
                height: MediaQuery.of(context).size.height,
                decoration: BoxDecoration(
                  boxShadow: [
                    BoxShadow(
                      color: Theme.of(context).secondaryHeaderColor,
                      blurRadius: 10,
                    )
                  ],
                  color: Theme.of(context).canvasColor,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(ScreenUtil().setWidth(75)),
                  ),
                ),
                child: Padding(
                  padding: EdgeInsets.all(ScreenUtil().setWidth(10)),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: EdgeInsets.all(ScreenUtil().setHeight(14)),
                        child: Text(
                          'Sentence',
                          style: TextStyle(
                            fontFamily: 'Montserrat',
                            fontWeight: FontWeight.bold,
                            fontSize: ScreenUtil().setSp(20),
                            color: Color(0xFF21BFBD),
                          ),
                        ),
                      ),
                      ColoredBox(
                        color: Colors.blue.shade300,
                        child: Padding(
                          padding: EdgeInsets.all(ScreenUtil().setHeight(16)),
                          child: Text(
                            widget.reading.sentence,
                            style: TextStyle(
                              fontSize: ScreenUtil().setSp(16),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(height: ScreenUtil().setHeight(20)),
                      Padding(
                        padding: EdgeInsets.all(ScreenUtil().setHeight(8)),
                        child: Text(
                          'Options',
                          style: TextStyle(
                            fontFamily: 'Montserrat',
                            fontWeight: FontWeight.bold,
                            fontSize: ScreenUtil().setSp(20),
                            color: Color(0xFF21BFBD),
                          ),
                        ),
                      ),
                      ColoredBox(
                        color: Colors.blue.shade300,
                        child: Padding(
                          padding: EdgeInsets.all(ScreenUtil().setHeight(16)),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: List.generate(
                              widget.reading.options.length,
                                  (index) => CheckboxListTile(
                                title: Text(widget
                                    .reading.options[index]
                                    .replaceAll('_n', '\n')),
                                value: selectedOptions[index],
                                onChanged: (value) {
                                  setState(() {
                                    selectedOptions[index] = value ?? false;
                                  });
                                },
                                controlAffinity:
                                ListTileControlAffinity.leading,
                              ),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(height: ScreenUtil().setHeight(20)),
                      Padding(
                        padding: EdgeInsets.all(ScreenUtil().setHeight(8)),
                        child: Text(
                          'Correct Option',
                          style: TextStyle(
                            fontFamily: 'Montserrat',
                            fontWeight: FontWeight.bold,
                            fontSize: ScreenUtil().setSp(20),
                            color: Color(0xFF21BFBD),
                          ),
                        ),
                      ),
                      Align(
                        alignment: Alignment.bottomCenter,
                        child: MaterialButton(
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10)),
                          onPressed: () {
                            setState(() {
                              showColoredBox = true;
                            });
                          },
                          child: Text('Answer',
                              style: TextStyle(
                                fontSize: ScreenUtil().setSp(20),
                                fontFamily: 'Montserrat',
                              )),
                          color: Colors.deepPurpleAccent,
                          textColor: Colors.white,
                          elevation: 5,
                        ),
                      ),
                      if (showColoredBox)
                        Center(
                          child: ColoredBox(
                            color: Colors.blue.shade300,
                            child: Padding(
                              padding: EdgeInsets.all(ScreenUtil().setHeight(16)),
                              child: Text(
                                widget.reading.correctOption,
                                style: TextStyle(
                                  fontSize: ScreenUtil().setSp(16),
                                ),
                              ),
                            ),
                          ),
                        ),




                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
