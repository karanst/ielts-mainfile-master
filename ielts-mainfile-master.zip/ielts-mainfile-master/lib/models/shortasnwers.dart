class ShortAnswer {
  String id;
  String question;
  String? userAnswer;
  String level;

  ShortAnswer({
    required this.id,
    required this.question,
    required this.level,
    this.userAnswer,
  });

  ShortAnswer.fromMap(Map<String, dynamic> map, String id)
      : id = map['id'] ?? '',
        question = map['question'] ?? '',
        level = map['level'] ?? '',
        userAnswer = map['userAnswer'];

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'question': question,
      'level' : level,
      'userAnswer': userAnswer,
    };
  }
}
