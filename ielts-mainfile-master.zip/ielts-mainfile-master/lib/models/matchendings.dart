class MatchEndings {
  String id;
  String mainText;
  String text;
  String level;
  String? endingText;

  MatchEndings({
    required this.id,
    required this.mainText,
    required this.text,
    required this.level,
    this.endingText,
  });

  MatchEndings.fromMap(Map<String, dynamic> map, String id)
      : id = map['id'] ?? '',
        mainText = map['mainText'] ?? '',
        level = map['level'] ?? '',
        text = map['text'] ?? '',
        endingText = map['endingText'] ?? '';

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'mainText': mainText,
      'text': text,
      'endingText': endingText,
      'level': level,
    };
  }
}
