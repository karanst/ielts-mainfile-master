import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../models/listselection.dart';

class ListSelectionDetailScreen extends StatefulWidget {
  final ListSelection reading;

  ListSelectionDetailScreen({required this.reading});

  @override
  _ListSelectionDetailScreenState createState() =>
      _ListSelectionDetailScreenState();
}

class _ListSelectionDetailScreenState extends State<ListSelectionDetailScreen> {
  @override
  Widget build(BuildContext context) {
    ScreenUtil.init(context); // Initialize ScreenUtil

    return Scaffold(
      appBar: AppBar(
        title: Text(
          'List Selection Detail',
          maxLines: 2,
          overflow: TextOverflow.ellipsis, // Add overflow for long titles
          style: TextStyle(
            fontFamily: 'Montserrat',
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: ScreenUtil().setSp(18),
          ),
        ),
        elevation: 0.0,
        backgroundColor: Theme.of(context).primaryColor,
        bottomOpacity: 0.0,
      ),
      body: Padding(
        padding: EdgeInsets.all(ScreenUtil().setWidth(0)), // Adjust padding
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start, // Align content to start
            children: [
              SizedBox(height: ScreenUtil().setHeight(20)),
              Container(
                height: MediaQuery.of(context).size.height,
                decoration: BoxDecoration(
                  boxShadow: [
                    BoxShadow(
                      color: Theme.of(context).secondaryHeaderColor,
                      blurRadius: 10,
                    )
                  ],
                  color: Theme.of(context).canvasColor,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(ScreenUtil().setWidth(75)),
                  ),
                ),
                child: Padding(
                  padding: EdgeInsets.all(ScreenUtil().setWidth(10)),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: EdgeInsets.all(ScreenUtil().setHeight(14)),
                        child: Text(
                          'List Selection Detail                   ',
                          style: TextStyle(
                            fontFamily: 'Montserrat',
                            fontWeight: FontWeight.bold,
                            fontSize: ScreenUtil().setSp(20),
                            color: Color(0xFF21BFBD),
                          ),
                        ),
                      ),
                      SizedBox(height: ScreenUtil().setHeight(20)),
                      Text(
                        'List: ${widget.reading.name}',
                        style: TextStyle(
                          fontFamily: 'Montserrat',
                          fontSize: ScreenUtil().setSp(16),
                        ),
                      ),
                      Text(
                        'Is Selected: ${widget.reading.isSelected}',
                        style: TextStyle(
                          fontFamily: 'Montserrat',
                          fontSize: ScreenUtil().setSp(16),
                        ),
                      ),
                      Text(
                        'Description: ${widget.reading.question}',
                        style: TextStyle(
                          fontFamily: 'Montserrat',
                          fontSize: ScreenUtil().setSp(16),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}